/* Applied Video Sequence Analysis (AVSA)
 *
 *	LAB1.0: Background Subtraction - Unix version
 *	fgesg.cpp
 *
 * 	Authors: José M. Martínez (josem.martinez@uam.es), Paula Moral (paula.moral@uam.es) & Juan Carlos San Miguel (juancarlos.sanmiguel@uam.es)
 *	VPULab-UAM 2020
 */

#include <opencv2/opencv.hpp>
#include "fgseg.hpp"

using namespace fgseg;

//default constructor

bgs::bgs(double threshold, double alpha, int threshold_ghosts2, bool rgb) {
	_rgb = rgb;

	_threshold = threshold;

	//New parameters for the constructor
	_alpha = alpha;

	_threshold_ghosts2 = threshold_ghosts2;

}

//default destructor
bgs::~bgs(void) {
}

//method to initialize bkg (first frame - hot start)
void bgs::init_bkg(cv::Mat Frame) {

	if (!_rgb) {
		cvtColor(Frame, Frame, COLOR_BGR2GRAY); // to work with gray even if input is color

		// Initial backgrund
		_bkg = Mat::zeros(Size(Frame.cols, Frame.rows), CV_8UC1); // void function for Lab1.0 - returns zero matrix
		Frame.copyTo(_bkg);

		// Initialize mean and variance for Gaussian
		_mean = Mat::zeros(Size(Frame.cols, Frame.rows), CV_32F);
		_variance = Mat::zeros(Size(Frame.cols, Frame.rows), CV_32F);

		// Initial masks
		_bgsmask = Mat::zeros(Size(Frame.cols, Frame.rows), CV_8UC1);
		_shadowmask = Mat::zeros(Size(Frame.cols, Frame.rows), CV_8UC1);

		// Initialize counter for suppression of ghosts
		counter = cv::Mat::zeros(Size(Frame.cols, Frame.rows), CV_8UC1);

		//...
	} else {
		// Initialize _bkg for rgb input
		//CV_<bit-depth>{U|S|F}C(<number_of_channels>)
		_bkg = Mat::zeros(Size(Frame.cols, Frame.rows), CV_8UC3);
		Frame.copyTo(_bkg);

		// Initial masks
		_shadowmask = Mat::zeros(Size(Frame.cols, Frame.rows), CV_8UC1);
		_bgsmask = Mat::zeros(Size(Frame.cols, Frame.rows), CV_8UC1);

		// Initialize counter for suppression of ghosts
		counter = cv::Mat::zeros(Size(Frame.cols, Frame.rows), CV_8UC3);

		// Initialize mean and variance for Gaussian
		_mean = Mat::zeros(Size(Frame.cols, Frame.rows), CV_32FC3);
		_variance = Mat::zeros(Size(Frame.cols, Frame.rows), CV_32FC3);

	}

}

//method to perform Single Gaussian BackGroundSubtraction
void bgs::bkgSubtraction(cv::Mat Frame, int it) {

	if (!_rgb) {

		// converting frame to CV_32F type "gray" variable
		cvtColor(Frame, Frame, COLOR_BGR2GRAY); // to work with gray even if input is color
		cv::Mat gray;
		Frame.convertTo(gray,CV_32F);
		Frame.copyTo(_frame);

		// Initial mask
		_bgsmask = Mat::zeros(Size(Frame.cols, Frame.rows), CV_8UC1);


		// Initial mean
		if (it==1){
			gray.copyTo(_mean);
		}

		//Loop through every pixel
		for (int i = 0; i < _frame.rows; ++i) {
			for (int j = 0; j < _frame.cols; ++j) {

				// Condition for masking
				if (abs(gray.at<float>(i, j) - _mean.at<float>(i, j)) <= 3*(_variance.at<float>(i, j))) {
					_bgsmask.at<uchar>(i, j) = 0;
					_bkg.at<uchar>(i, j) = (gray.at<float>(i, j));

				}
				else {
					_bgsmask.at<uchar>(i, j) = 255;

					// Updating mean and variance
					_mean.at<float>(i, j) = _alpha * gray.at<float>(i, j) + ((1 - _alpha) * _mean.at<float>(i, j));
					_variance.at<float>(i, j) = pow(_alpha * (pow((gray.at<float>(i, j) - _mean.at<float>(i, j)),	2))	+ ((1 - _alpha) * _variance.at<float>(i, j)),0.5);


				}

			}
		}
		// Initial difference
		_diff = Mat::zeros(Size(Frame.cols, Frame.rows), CV_8UC1); // void function for Lab1.0 - returns zero matrix

	} else {
		// Initial mask
		_bgsmask = Mat::zeros(Size(Frame.cols, Frame.rows), CV_8UC1);

		// converting frame to CV_32F type "gray" variable
		cv::Mat gray;
		Frame.convertTo(gray,CV_32F);
		Frame.copyTo(_frame);

		// Initial mean
		if (it==1){
			gray.copyTo(_mean);
		}

		//Loop through every pixel
		for (int i = 0; i < _frame.rows; ++i) {
			for (int j = 0; j < _frame.cols; ++j) {

				// Loop through the three channels
				for (int k = 0; k < 3; k++) {

					// Condition for masking
					if (abs( _frame.at<cv::Vec3b>(i, j)[k]- _mean.at<cv::Vec3f>(i, j)[k]) <= 3*_variance.at<cv::Vec3f>(i, j)[k]) {
						_bgsmask.at<uchar>(i, j) = 0;
						_bkg.at<cv::Vec3b>(i, j)[k] = _frame.at<cv::Vec3b>(i, j)[k];

					}
					else {

						_bgsmask.at<uchar>(i, j) = 255;
						// Updating mean and variance
						_mean.at<cv::Vec3f>(i, j)[k] = _alpha * _frame.at<cv::Vec3b>(i, j)[k]+ ((1 - _alpha) * _mean.at<cv::Vec3f>(i, j)[k]);
						_variance.at<cv::Vec3f>(i, j)[k] = pow(_alpha * (pow( (_frame.at<cv::Vec3b>(i, j)[k] - _mean.at<cv::Vec3f>(i, j)[k]), 2)) + ((1 - _alpha) * _variance.at<cv::Vec3f>(i, j)[k]),0.5);

					}

				}
			}
		}
		// Initial difference
		_diff = Mat::zeros(Size(Frame.cols, Frame.rows), CV_8UC3); // void function for Lab1.0 - returns zero matrix
	}
	// Calculating difference for both rgb and gray-scale
	_diff = abs(_frame - _bkg);
}

//method to detect and remove shadows in the BGS mask to create FG mask
void bgs::removeShadows() {
	//ADD YOUR CODE HERE
	//...
	// Converting background mask back if needed
	if (_bgsmask.type() == 16) {
		cvtColor(_bgsmask, _bgsmask, CV_RGB2GRAY);
	}
	absdiff(_bgsmask, _shadowmask, _fgmask); // eliminates shadows from bgsmask
}

//ADD ADDITIONAL FUNCTIONS HERE

void bgs::update_shadowmask(cv::Mat Frame, double alpha_shdw,double beta_shdw,double tau_shdw_s,double tau_shdw_h) {

// For rgb calculating the shadow suppression
if(_rgb){

	// Initialize and convert to hsv
	cv::Mat hsv_frame = cv::Mat::zeros(Size(Frame.cols, Frame.rows), CV_8UC3);
	cvtColor( Frame,hsv_frame, CV_BGR2HSV); // converting rgb to hsv

	cv::Mat hsv_bkg = cv::Mat::zeros(Size(Frame.cols, Frame.rows), CV_8UC3);
	cvtColor( _bkg,hsv_bkg, CV_BGR2HSV); // converting rgb to hsv

	_shadowmask = Mat::zeros(Size(Frame.cols,Frame.rows), CV_8UC1);

	// help funtion for noise filtering
	cv::Mat help = Mat::zeros(Size(Frame.cols,Frame.rows), CV_8UC1);
	_bgsmask.copyTo(help);
	if (_bgsmask.type() == 16){
		cvtColor(_bgsmask,help,CV_RGB2GRAY);
	}

//	//Loop through every pixel
	for (int i = 0; i < hsv_frame.rows; ++i) {
		for (int j = 0; j < hsv_frame.cols; ++j) {
			// Create the frame HSV values
	    	double pixel_frame_H = double(hsv_frame.at<cv::Vec3b>(i, j)[0]) *2;
	    	double pixel_frame_S = double(hsv_frame.at<cv::Vec3b>(i, j)[1]);
	    	double pixel_frame_V = double(hsv_frame.at<cv::Vec3b>(i, j)[2]);
	    	if (pixel_frame_V ==0){
	    		pixel_frame_V = 1.0;
	    	}

	    	// Create the BKG HSV values
	    	double pixel_bkg_H = double(hsv_bkg.at<cv::Vec3b>(i, j)[0])*2;
	    	double pixel_bkg_S = double(hsv_bkg.at<cv::Vec3b>(i, j)[1]);
	    	double pixel_bkg_V = double(hsv_bkg.at<cv::Vec3b>(i, j)[2]);


	    	// Calculate the needed equations
			double compare_alpha_beta = pixel_frame_V /  pixel_bkg_V;
			double compare_beta = std::abs(pixel_frame_S - pixel_bkg_S);
			double Dh = std::min(double(std::abs(pixel_frame_H - pixel_bkg_H)), double(360 - std::abs(pixel_frame_H - pixel_bkg_H)));

			// Condition for shadowmask
			if((alpha_shdw <= compare_alpha_beta) && (compare_alpha_beta <= beta_shdw) && (compare_beta <= tau_shdw_s) && (Dh <= tau_shdw_h)) {
				_shadowmask.at<uchar>(i, j) = 255;

				// Noise filtering
				if(help.at<uchar>(i, j) == 0){
					_shadowmask.at<uchar>(i, j) = 0;
				}

			}
		}
	}
}
}

