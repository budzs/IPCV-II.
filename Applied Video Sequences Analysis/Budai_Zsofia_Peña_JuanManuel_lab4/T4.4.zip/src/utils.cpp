/* Applied Video Sequence Analysis - Escuela Politecnica Superior - Universidad Autonoma de Madrid
 *
 *	This source code belongs to the template code for
 *	the assignment LAB 4 "Histogram-based tracking"
 *
 *	Implementation of utilities for LAB4.
 *
 * Author: Juan C. SanMiguel (juancarlos.sanmiguel@uam.es)
 * Date: April 2020
 */
#include <opencv2/opencv.hpp>
#include "utils.hpp"

using namespace cv;
using namespace std;

/**
 * Reads a text file where each row contains comma separated values of
 * corners of groundtruth bounding boxes.
 *
 * The annotations are stored in a text file with the format:
 * Row format is "X1, Y1, X2, Y2, X3, Y3, X4, Y4" where Xi and Yi are
 * the coordinates of corner i of the bounding box in frame N, which
 * corresponds to the N-th row in the text file.
 *
 * Returns a list of cv::Rect with the bounding boxes data.
 *
 * @param ground_truth_path: full path to ground truth text file
 * @return bbox_list: list of ground truth bounding boxes of class Rect
 */
std::vector<Rect> readGroundTruthFile(std::string groundtruth_path)
{
	// variables for reading text file
	ifstream inFile; //file stream
	string bbox_values; //line of file containing all bounding box data
	string bbox_value;  //a single value of bbox_values

	vector<Rect> bbox_list; //output with all read bounding boxes

	// open text file
	inFile.open(groundtruth_path.c_str(),ifstream::in);
	if(!inFile)
		throw runtime_error("Could not open groundtrutfile " + groundtruth_path); //throw error if not possible to read file

	// Read each line of groundtruth file
	while(getline(inFile, bbox_values)){

		stringstream linestream(bbox_values); //convert read line to linestream
		//cout << "-->lineread=" << linestream.str() << endl;

		// Read comma separated values of groundtruth.txt
		vector<int> x_values,y_values; 	//values to be read from line
		int line_ctr = 0;						//control variable to read alternate Xi,Yi
		while(getline(linestream, bbox_value, ',')){

			//read alternate Xi,Yi coordinates
			if(line_ctr%2 == 0)
				x_values.push_back(stoi(bbox_value));
			else
				y_values.push_back(stoi(bbox_value));
			line_ctr++;
		}

		// Get width and height; and minimum X,Y coordinates
		double xmin = *min_element(x_values.begin(), x_values.end()); //x coordinate of the top-left corner
		double ymin = *min_element(y_values.begin(), y_values.end()); //y coordinate of the top-left corner

		if (xmin < 0) xmin=0;
		if (ymin < 0) ymin=0;

		double width = *max_element(x_values.begin(), x_values.end()) - xmin; //width
		double height = *max_element(y_values.begin(), y_values.end()) - ymin;//height

		// Initialize a cv::Rect for a bounding box and store it in a std<vector> list
		bbox_list.push_back(Rect(xmin, ymin, width, height));
		//std::cout << "-->Bbox=" << bbox_list[bbox_list.size()-1] << std::endl;
	}
	inFile.close();

	return bbox_list;
}

/**
 * Compare two lists of bounding boxes to estimate their overlap
 * using the criterion IOU (Intersection Over Union), which ranges
 * from 0 (worst) to 1(best) as described in the following paper:
 * Čehovin, L., Leonardis, A., & Kristan, M. (2016).
 * Visual object tracking performance measures revisited.
 * IEEE Transactions on Image Processing, 25(3), 1261-1274.
 *
 * Returns a list of floats with the IOU for each frame.
 *
 * @param Bbox_GT: list of elements of type cv::Rect describing
 * 				   the groundtruth bounding box of the object for each frame.
 * @param Bbox_est: list of elements of type cv::Rect describing
 * 				   the estimated bounding box of the object for each frame.
 * @return score: list of float values (IOU values) for each frame
 *
 * Comments:
 * 		- The two lists of bounding boxes must be aligned, meaning that
 * 		position 'i' for both lists corresponds to frame 'i'.
 * 		- Only estimated Bboxes are compared, so groundtruth Bbox can be
 * 		a list larger than the list of estimated Bboxes.
 */
std::vector<float> estimateTrackingPerformance(std::vector<cv::Rect> Bbox_GT, std::vector<cv::Rect> Bbox_est)
{
	vector<float> score;

	//For each data, we compute the IOU criteria for all estimations
	for(int f=0;f<(int)Bbox_est.size();f++)
	{
		Rect m_inter = Bbox_GT[f] & Bbox_est[f];//Intersection
		Rect m_union = Bbox_GT[f] | Bbox_est[f];//Union

		score.push_back((float)m_inter.area()/(float)m_union.area());
	}

	return score;
}

std::vector<cv::Rect> createCandidates(int numCand, cv::Rect pred, int w, int h, int step, cv::Size frameSize){
    std::vector<cv::Rect> candidates;
    // calculating the steps for the grid
    int stepX = std::max(pred.width / step, 1);
    int stepY = std::max(pred.height / step, 1);

    for (int i=-numCand; i<=numCand; i++){
        for (int j=-numCand; j<=numCand; j++){
            int x = pred.x+(i*stepX);
            int y = pred.y+(j*stepY);
            // check not to be out of the frame
            if (x >= 0 && y >= 0 && x + w <= frameSize.width && y + h <= frameSize.height) {
                candidates.push_back(Rect(x, y, w, h)); // store the candidates in the returning list
            }
        }
    }
    return candidates;
}


std::vector<double> compareCandidates(const cv::Mat& histogram, const std::vector<Rect>& candidates, std::string feature, char color_feature, Mat frame, int histSize) {
    std::vector<double> distances;

    cv::Mat hist32F;
    histogram.convertTo(hist32F, CV_32F); // Convert the histogram to CV_32F
	cv::Mat c_out_box_image;
	cv::Mat c_histogram;

    for (const cv::Rect& candidate : candidates) {
		c_histogram = computeHistrogram(frame(candidate),  c_out_box_image,  feature, color_feature, histSize);

        cv::Mat candidate32F;
        c_histogram.convertTo(candidate32F, CV_32F); // Convert the candidate histogram to CV_32F

        // the template matching
        double result = compareHist(hist32F, candidate32F, CV_COMP_BHATTACHARYYA);
        distances.push_back(result);
    }

    return distances;
}


/**
Computes the histogram of a given input image based on the specified feature
 and color feature. It takes the following parameters:

    @param box_image: The input image for which the histogram needs to be computed.

    @param out_box_image: Reference to the output image, which represents the selected
    feature of the input image.

    @param feature: A string specifying the feature type. It can be one of the following
     values: "RGB", "HSV", "HOG", or "GRAY".

    @param color_feature: A character representing the color feature to be considered.
    The valid values depend on the chosen feature. For "RGB" and "HSV" features,
    it can be 'B', 'G', or 'R' for RGB channels, and 'H' or 'S' for HSV channels.
    For "HOG" and "GRAY" features, it is not used and can be any character.

The function first splits the input image into color channels if the feature is "RGB".
The appropriate channel is selected based on the given color feature, and the corresponding
color is set. If the feature is "HSV", the input image is converted to HSV color space, split
into channels, and the color channel is selected based on the given color feature. If the feature
is "HOG", the input image is converted to grayscale, and the color feature is ignored. If the
feature is "GRAY", the input image is converted to grayscale, and the color feature is ignored.

After selecting the appropriate channel or converting to grayscale, the function computes the
histogram using either the gethistogram function or the computeHOG function. The histSize parameter
specifies the number of bins for the histogram.

Finally, the computed histogram is returned as the function result.

Note: There are some commented-out code lines and error handling messages that are not used in the current implementation.
 */

cv::Mat computeHistrogram(cv::Mat box_image, cv::Mat &out_box_image,
	std::string feature, char color_feature, int histSize) {
	std::vector<Mat> channels;
	cv::Mat histogram;
	cv::Mat hsv_box_image;
	cv::Mat gray_box_image;

	// compute histogram
	Scalar color;

	if (feature == "RGB") {
		split(box_image, channels);
		switch (color_feature) {
		case 'B':
			out_box_image = channels[0];
			color = Scalar(255, 0, 0);
			break;
		case 'G':
			out_box_image = channels[1];
			color = Scalar(0, 255, 0);
			break;
		case 'R':
			out_box_image = channels[2];
			color = Scalar(0, 0, 255);
			break;
		default:
			std::cout << "Error: Color feature value is not correct for RGB"
					<< endl;
			break;
		}
		// GET HISTOGRAM
		histogram = gethistogram(color, out_box_image, histSize);
		//std::cout << color_feature << std::endl;

	} else if (feature == "HSV") {
		cvtColor(box_image, hsv_box_image, COLOR_BGR2HSV);
		split(hsv_box_image, channels);
		switch (color_feature) {
		case 'H':
			out_box_image = channels[0];
			color = Scalar(255, 0, 0);
			break;
		case 'S':
			out_box_image = channels[1];
			color = Scalar(0, 255, 0);
			break;
		default:
			cout << "Error: Color feature value is not correct for HSV" << endl;
			break;
		}
		// GET HISTOGRAM
		histogram = gethistogram(color, out_box_image, histSize);

		//std::cout << color_feature << std::endl;
	} else if (feature == "HOG") {
		color_feature = '0';

		//HOG features only for Gray image
		cvtColor(box_image, out_box_image, COLOR_RGB2GRAY);


		color = Scalar(255, 255, 255);
		// GET HISTOGRAM
		histogram = computeHOG(out_box_image, histSize);
		//std::cout << "HOG" << std::endl;;
	} else if (feature == "GRAY") {
		cvtColor(box_image, out_box_image, COLOR_BGR2GRAY);
		color = Scalar(255, 255, 255);
		// GET HISTOGRAM
		histogram = gethistogram(color, out_box_image, histSize);

		//std::cout << "gray" << std::endl;
	} else {
		std::cout << "Error: Feature value is not correct" << endl;

	}


	putText(histogram,"Feature:  " + feature + " " + "->" + " " + color_feature , cvPoint(30,30),FONT_HERSHEY_COMPLEX_SMALL, 1.3, cvScalar(255,255,255), 1, CV_AA);


	return histogram;
}

cv::Mat gethistogram(Scalar color, cv::Mat &out_box_image,  int histSize) {
	Mat hist;

    float range[] = { 0, 256 }; //the upper boundary is exclusive
    const float* histRange = { range };
	bool uniform = true, accumulate = false;
	int hist_w = 512, hist_h = 400;
	int bin_w = cvRound( (double) hist_w/histSize );
	Mat histImage( hist_h, hist_w, CV_8UC3, Scalar( 0,0,0) );

	calcHist(&out_box_image, 1, 0, Mat(), hist, 1, &histSize, &histRange, uniform, accumulate);


	// normalization
	int numSamples = out_box_image.rows * out_box_image.cols;
	for (int i = 0; i < histSize; i++) {
	    hist.at<float>(i) /= numSamples;
	}

	// Draw the histogram bars
	for (int i = 1; i < histSize; i++) {
	    cv::line(histImage,
	             cv::Point(bin_w * (i - 1), hist_h - cvRound(hist.at<float>(i - 1) * hist_h)),
	             cv::Point(bin_w * i, hist_h - cvRound(hist.at<float>(i) * hist_h)),
	             cv::Scalar(255,255,255),
	             2);
	}


    return histImage;
}

cv::Mat computeHOG(cv::Mat out_box_image, int histSize)
{


	int cellSize = 8;  // Size of HOG cell
	HOGDescriptor hog;
	vector<float> descriptor; // HOG Feature vector.

	// Resize the image to 64x128
    cv::Size newSize(64, 128);

    cv::resize(out_box_image, out_box_image, newSize);

	hog.nbins=histSize;
	hog.compute(out_box_image,descriptor,Size( cellSize, cellSize ), Size( 0, 0 ) );
	Mat hog_img = Mat(descriptor).clone();


	//std::cout << "Size of hog_histImage: " << descriptor.size() << std::endl;


	//==========================================================================================
	//OPTION 1: Create an image to draw the HOG features
	//==========================================================================================
		cv::Mat hogImage = cv::Mat::zeros(out_box_image.size(), CV_8UC1);
		// Number of cells for plotting HOF features
		int cellsX = hogImage.cols / cellSize;
		int cellsY = hogImage.rows / cellSize;

		// Iterate over the HOG descriptor and draw lines
		for (int y = 0; y < cellsY; y++) {
		    for (int x = 0; x < cellsX; x++) {
		        cv::Point cellStart(x * cellSize, y * cellSize);
		        cv::Point cellCenter(cellStart.x + cellSize / 2, cellStart.y + cellSize / 2);
		        int descriptorIdx = y * cellsX + x;
		        float gradientOrientation = descriptor[descriptorIdx];
		        float angle = (gradientOrientation + 180.0f) * CV_PI / 180.0f;
		        int lineLength = cellSize / 2;
		        cv::Point lineEnd(static_cast<int>(cellCenter.x + lineLength * cos(angle)),
		                          static_cast<int>(cellCenter.y + lineLength * sin(angle)));
		        cv::line(hogImage, cellCenter, lineEnd, cv::Scalar(255));
		    }
		}

	//==========================================================================================
	//OPTION 2: avergae histogram across all the cells
	//==========================================================================================
	int nbins = histSize;
	std::vector<float> meanHistogram(nbins, 0.0f);

	int numCells = descriptor.size() / nbins;
	for (int cellIndex = 0; cellIndex < numCells; cellIndex++) {
	    for (int binIndex = 0; binIndex < nbins; binIndex++) {
	        int descriptorIndex = cellIndex * nbins + binIndex;
	        meanHistogram[binIndex] += descriptor[descriptorIndex];
	    }
	}

	float totalCells = static_cast<float>(numCells);
	for (int binIndex = 0; binIndex < nbins; binIndex++) {
	    meanHistogram[binIndex] /= totalCells;
	}

	float sumHistogram = 0.0f;
	for (int binIndex = 0; binIndex < nbins; binIndex++) {
	    sumHistogram += meanHistogram[binIndex];
	}

	for (int binIndex = 0; binIndex < nbins; binIndex++) {
	    meanHistogram[binIndex] /= sumHistogram;
	}

	// Calculate the sum of all values in the meanHistogram
	sumHistogram = 0.0f;
	for (int binIndex = 0; binIndex < histSize; binIndex++) {
	    sumHistogram += meanHistogram[binIndex];
	}

	// Display the sum of the histogram values
	//std::cout << "Sum of Histogram Values: " << sumHistogram << std::endl;
	// Display all histogram values
	for (int binIndex = 0; binIndex < histSize; binIndex++) {
	    //std::cout << "Bin " << binIndex << ": " << meanHistogram[binIndex] << std::endl;
	}



	//Drawing the histogram from the avreage
	int hist_w = 1280;  // Width of the histogram image
	int hist_h = 720;  // Height of the histogram image
	int bin_w = cvRound(static_cast<float>(hist_w) / histSize);

	//Mat to draw the histogram
	cv::Mat histImage(hist_h, hist_w, CV_8UC3, cv::Scalar(0, 0, 0));

	// Normalize the meanHistogram values to fit within the histogram image height
	cv::normalize(meanHistogram, meanHistogram, 0, hist_h, cv::NORM_MINMAX, -1, cv::Mat());

	// Place histogram values
	for (int i = 1; i < histSize; i++) {
	    cv::line(histImage,
	             cv::Point(bin_w * (i - 1), hist_h - cvRound(meanHistogram[i - 1])),
	             cv::Point(bin_w * i, hist_h - cvRound(meanHistogram[i])),
	             cv::Scalar(255, 255, 255),
	             2);
	}




	return histImage;

}










