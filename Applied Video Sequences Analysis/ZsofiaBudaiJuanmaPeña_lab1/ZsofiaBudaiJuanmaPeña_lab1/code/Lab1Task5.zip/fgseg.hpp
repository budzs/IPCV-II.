/* Applied Video Sequence Analysis (AVSA)
 *
 *	LAB1.0: Background Subtraction - Unix version
 *	fgesg.hpp
 *
 * 	Authors: José M. Martínez (josem.martinez@uam.es), Paula Moral (paula.moral@uam.es) & Juan Carlos San Miguel (juancarlos.sanmiguel@uam.es)
 *	VPULab-UAM 2020
 */

#include <opencv2/opencv.hpp>

#ifndef FGSEG_H_INCLUDE
#define FGSEG_H_INCLUDE

using namespace cv;
using namespace std;

namespace fgseg {

class gaussianMM {
private:

	//Variables storing the gaussian parameters for each pixel
	vector<cv::Mat> _meanGMM;
	vector<cv::Mat> _sigmaGMM;
	vector<cv::Mat> _weightsGMM;

	cv::Mat _Ngaussians;//Number of active Gaussians for every pixel
	cv::Mat _ForegroundGMM; //Intermediary variable for storing the resulting mask
	cv::Mat _GaussLessWeight; //Stores the index of Gaussian with less weight

	int _K;
	int _initial_sigma;
	double _alphaGMM;
	double _weight_delta;

	void normalize_weights(int i, int j, int c);
	void refine_gaussian(int pixel_value, int i, int j, int c, int g);
	bool is_pixel_in_gaussian(int pixel_value,int i, int j, int c,int g);
	void update_weights(int i,int j,int c,vector<int> selected_Gaussians,vector<int> not_selected_Gaussians);

public:

	gaussianMM(cv::Mat Frame, int mode, bool rgb, int K,double alpha, int initial_std, double weight_delta); //Constructor of the Gaussian Parameters with the slected mode

	void update_params(cv::Mat Frame,double w_ratio_old2new_gaussian);//Update mean, deviation and weights according to given frame

	void update_GMM_mask(cv::Mat Frame,double threshold);

	cv::Mat getforegroundGMM() {
		return _ForegroundGMM;
	}

	vector<cv::Mat> getmeanGMM() {
		return _meanGMM;
	}
	vector<cv::Mat> getsigmaGMM() {
		cv::Mat element = _sigmaGMM[0];
		//imshow("Prueba sigmaa", element);
		//cout << "prueba_Sigma at start : " << element.cols << " by " << element.rows << endl;
		//cout << "Pixel 1 1 : " << element.at<cv::Vec3d>(2, 2)[0] << " , "<< element.at<cv::Vec3d>(2,2)[1] << " , "<< element.at<cv::Vec3d>(2,2)[2] << endl;
		//cout << "Pixel e e : " << element.at<cv::Vec3d>(element.cols-2, element.rows-2)[0] << " , "<< element.at<cv::Vec3d>(element.cols-2, element.rows-2)[1] << " , "<< element.at<cv::Vec3d>(element.cols-2, element.rows-2)[2] << endl;
		return _sigmaGMM;

	}
	vector<cv::Mat> getweightsGMM() {
		return _weightsGMM;
	}





};

//Declaration of FGSeg class based on BackGround Subtraction (bgs)
class bgs {
public:

	// Constructor with parameter "threshold","alpha", "selective_bkg_update", "threshold_ghosts2" and "rgb"
	bgs(double threshold, double alpha, int threshold_ghosts2, bool rgb);

	//destructor
	~bgs(void);

	//method to initialize bkg (first frame - hot start)
	void init_bkg(cv::Mat Frame);

	//method to perform BackGroundSubtraction
	void bkgSubtraction(cv::Mat Frame);

	//method to detect and remove shadows in the binary BGS mask
	void removeShadows();

	//returns the BG image
	cv::Mat getBG() {
		return _bkg;
	}
	;

	//returns the DIFF image
	cv::Mat getDiff() {
		return _diff;
	}
	;

	//returns the BGS mask
	cv::Mat getBGSmask() {
		return _bgsmask;
	}
	;

	//returns the binary mask with detected shadows
	cv::Mat getShadowMask() {
		return _shadowmask;
	}
	;

	//returns the binary FG mask
	cv::Mat getFGmask() {
		return _fgmask;
	}
	;

	//ADD ADITIONAL METHODS HERE
	// void counterInitial(cv::Mat Frame);
	void update_shadowmask(cv::Mat Frame, double alpha_shdw,double beta_shdw,double tau_shdw_s,double tau_shdw_h);
private:
	cv::Mat _bkg; //Background model
	cv::Mat _frame; //current frame
	cv::Mat _diff; //abs diff frame
	cv::Mat _bgsmask; //binary image for bgssub (FG)
	cv::Mat _shadowmask; //binary mask for detected shadows
	cv::Mat _fgmask; //binary image for foreground (FG)
	cv::Mat counter;

	bool _rgb;

	double _threshold;
	//ADD ADITIONAL VARIABLES HERE
	//...
	double _alpha;
	int _threshold_ghosts2;

};
//end of class bgs

}//end of namespace

#endif
/*
 * fseg.hpp
 *
 *  Created on: Mar 4, 2023
 *      Author: avsa
 */




