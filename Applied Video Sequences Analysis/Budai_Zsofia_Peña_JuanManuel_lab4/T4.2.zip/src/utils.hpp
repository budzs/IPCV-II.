/* Applied Video Sequence Analysis - Escuela Politecnica Superior - Universidad Autonoma de Madrid
 *
 *	This source code belongs to the template code for
 *	the assignment LAB 4 "Histogram-based tracking"
 *
 *	Header of utilities for LAB4.
 *	Some of these functions are adapted from OpenSource
 *
 * Author: Juan C. SanMiguel (juancarlos.sanmiguel@uam.es)
 * Date: April 2020
 */
#ifndef UTILS_HPP_
#define UTILS_HPP_

#include <string> 		// for string class
#include <opencv2/opencv.hpp>

std::vector<cv::Rect> readGroundTruthFile(std::string groundtruth_path);
std::vector<float> estimateTrackingPerformance(std::vector<cv::Rect> Bbox_GT, std::vector<cv::Rect> Bbox_est);
std::vector<cv::Rect> createCandidates(int gridSize, cv::Rect pred, int w, int h, int cand, cv::Size frameSize);
std::vector<double> compareCandidates(const cv::Mat& histogram, const std::vector<cv::Rect>& candidates, std::string feature, char color_feature, cv::Mat frame, int histSize);
cv::Mat computeHistrogram(cv::Mat box_image, cv::Mat & out_box_image,	std::string feature, char color_feature, int histSize);
cv::Mat gethistogram(cv::Scalar color, cv::Mat &out_box_image,  int histSize);
cv::Mat computeHOG(cv::Mat ROI, int histSize);

#endif /* UTILS_HPP_ */
