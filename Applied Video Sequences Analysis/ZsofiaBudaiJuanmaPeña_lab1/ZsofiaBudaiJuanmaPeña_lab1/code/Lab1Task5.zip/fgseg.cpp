/* Applied Video Sequence Analysis (AVSA)
 *
 *	LAB1.0: Background Subtraction - Unix version
 *	fgesg.cpp
 *
 * 	Authors: José M. Martínez (josem.martinez@uam.es), Paula Moral (paula.moral@uam.es) & Juan Carlos San Miguel (juancarlos.sanmiguel@uam.es)
 *	VPULab-UAM 2020
 */

#include <opencv2/opencv.hpp>
#include "fgseg.hpp"

using namespace fgseg;

// Class gaussian

gaussianMM::gaussianMM(cv::Mat Frame,int mode, bool rgb, int K,double alpha ,int initial_std, double weight_delta){

	cout << "Contructing the gaussianMM object  " << endl;

	_K = K;
	_alphaGMM = alpha;
	_initial_sigma= initial_std;
	_weight_delta = weight_delta;
	_Ngaussians = cv::Mat::ones(Size(Frame.cols, Frame.rows), CV_8UC3);
	_ForegroundGMM = cv::Mat::zeros(Size(Frame.cols, Frame.rows), CV_8UC3);
	_GaussLessWeight = cv::Mat::zeros(Size(Frame.cols, Frame.rows), CV_8UC3);
	//Initialize Mean Values

	for (int i = 0; i < K; ++i) {

			cv::Mat init_mean = cv::Mat::zeros(Size(Frame.cols, Frame.rows), CV_64FC3);
			for (int i = 0; i < init_mean.rows; ++i) {
				for (int j = 0; j < init_mean.cols; ++j) {
					for(int c = 0; c < 3; ++c){//Iteration over each channel
						if(i==0){
							//Creation of main gaussian)
							init_mean.at<Vec3d>(i, j)[c] = Frame.at<Vec3d>(i, j)[c];
						}else{
							init_mean.at<Vec3d>(i, j)[c] = -1;
						}
					}
				}
			}
			_meanGMM.push_back(init_mean);
	}

	//Initialize std
	for (int i = 0; i < K; ++i) {
		cv::Mat init_std = cv::Mat::zeros(Size(Frame.cols, Frame.rows), CV_64FC3);
		for (int i = 0; i < init_std.rows; ++i) {
			for (int j = 0; j < init_std.cols; ++j) {
				for(int c = 0; c < 3; ++c){//Iteration over each channel
					init_std.at<Vec3d>(i, j)[c] = double(initial_std);
				}
			}
		}
		_sigmaGMM.push_back(init_std);
		cout << "init_std at start : " << init_std.cols << " by " << init_std.rows << endl;
	}

	//Initialize weights
	for (int i = 0; i < K; ++i) {
		if(i==0){
			//Creation of weights of first gaussian
			cv::Mat weight_mainG = cv::Mat::zeros(Size(Frame.cols, Frame.rows), CV_8UC3);
			for (int i = 0; i < weight_mainG.rows; ++i) {
				for (int j = 0; j < weight_mainG.cols; ++j) {
					for(int c = 0; c < 3; ++c){//Iteration over each channel
						weight_mainG.at<cv::Vec3b>(i, j)[c] = 1;
					}
				}
			}
			_weightsGMM.push_back(weight_mainG);

		}else{
			cv::Mat weight_mainG = cv::Mat::zeros(Size(Frame.cols, Frame.rows), CV_64FC3);
			_weightsGMM.push_back(weight_mainG);
		}

	}

	cout << "Exiting the Contructing the gaussianMM object  " << endl;

}

bool inRange(int low, int high, int x)
{
    return ((x-high)*(x-low) <= 0);
}

void gaussianMM::normalize_weights(int i, int j, int c)
{
	double sumW = 0;
	int n_gaussians = _Ngaussians.at<cv::Vec3b>(i, j)[c];
	for(int g = 0; g < n_gaussians ; ++g){
		sumW = sumW + _weightsGMM[n_gaussians].at<cv::Vec3b>(i, j)[c];
	}

	for(int g = 0; g < n_gaussians ; ++g){
		_weightsGMM[n_gaussians].at<cv::Vec3b>(i, j)[c] = _weightsGMM[n_gaussians].at<cv::Vec3b>(i, j)[c] / sumW;
	}

	//Updating the gaussian with the minimum weight
	int min_g = 0;
	double min_val = _weightsGMM[0].at<cv::Vec3b>(i, j)[c];
	for (int g = 1; g < n_gaussians; g++) {
	    double val = _weightsGMM[g].at<cv::Vec3b>(i, j)[c];
	    if (val < min_val) {
	    	min_g = g;
	        min_val = val;
	    }
	}



	_GaussLessWeight.at<cv::Vec3b>(i, j)[c] = min_g;
}

void gaussianMM::refine_gaussian(int pixel_value, int i, int j, int c, int g)
{
	double old_mean = _meanGMM[g].at<cv::Vec3b>(i, j)[c];
	double old_sigma = _sigmaGMM[g].at<cv::Vec3b>(i, j)[c];
	// Refine the gaussians of the pixel according to the _alphaGMM
	//Refining the mean
	_meanGMM[g].at<cv::Vec3b>(i, j)[c] = _alphaGMM * pixel_value + (1 - _alphaGMM)*old_mean;
	//Refining the sigma

	_sigmaGMM[g].at<cv::Vec3b>(i, j)[c] = sqrt(_alphaGMM * pow(pixel_value - old_mean,2) + (1 - _alphaGMM) * pow(old_sigma,2));
}
void gaussianMM::update_weights(int i,int j,int c,vector<int> selected_Gaussians,vector<int> not_selected_Gaussians){
	if (!selected_Gaussians.empty()) {
	    for (int g : selected_Gaussians) {
	        // Increase the weight
	    	_weightsGMM[g].at<cv::Vec3b>(i, j)[c] = _weightsGMM[g].at<cv::Vec3b>(i, j)[c] + _weight_delta;
	    }
	}
	if (!not_selected_Gaussians.empty()) {
	    for (int g : not_selected_Gaussians) {
	        // Decrease weight
	    	_weightsGMM[g].at<cv::Vec3b>(i, j)[c] = _weightsGMM[g].at<cv::Vec3b>(i, j)[c] + _weight_delta;
	    }
	}
}

bool gaussianMM::is_pixel_in_gaussian(int pixel_value, int i, int j, int c,int g){
	int high = _meanGMM[g].at<cv::Vec3b>(i, j)[c]-_sigmaGMM[g].at<cv::Vec3b>(i, j)[c];
	int low = _meanGMM[g].at<cv::Vec3b>(i, j)[c]-_sigmaGMM[g].at<cv::Vec3b>(i, j)[c];
	return ((pixel_value-high)*(pixel_value-low) <= 0);
}


void gaussianMM::update_params(cv::Mat Frame,double w_ratio_old2new_gaussian){

	for (int i = 0; i < Frame.rows; ++i) {
		for (int j = 0; j < Frame.cols; ++j) {//Iteration over each pixel of the Frame

			for(int c = 0; c < 3; ++c){//Iteration over each channel

				int n_gaussians = _Ngaussians.at<cv::Vec3b>(i, j)[c];//Number of Gaussains included in c component of the
				int pixel_value = Frame.at<cv::Vec3b>(i, j)[c];
				bool pixel_in_any_gaussian = false;
				vector<int> selected_Gaussians;
				vector<int> not_selected_Gaussians;

				for(int g = 0; g < n_gaussians ; ++g){//Iteration over each Gaussian

					if(is_pixel_in_gaussian(pixel_value,i,j,c,g)){//Refine the gaussian-> update values of mean and sigma

						selected_Gaussians.push_back(g);
						this->refine_gaussian(pixel_value,i,j,c,g);
						pixel_in_any_gaussian = true;

					}else{//Pixel is not in this gaussian-> decrease the weight
						not_selected_Gaussians.push_back(g);
					}
				}//End loop through _K gaussians   _____________________________________________________

				this->update_weights(i,j,c,selected_Gaussians,not_selected_Gaussians);
				this->normalize_weights(i,j,c);

				if(!pixel_in_any_gaussian){

					//Creating a new gaussian for this pixel
					if(n_gaussians==_K){

						//Limit of gaussian reached, we need to erase the gaussian with less weight
						int iGaussLessW = _GaussLessWeight.at<cv::Vec3b>(i, j)[c];
						_meanGMM[iGaussLessW].at<cv::Vec3b>(i, j)[c] = Frame.at<cv::Vec3b>(i, j)[c];
						_sigmaGMM[iGaussLessW].at<cv::Vec3b>(i, j)[c] = _initial_sigma;
						_weightsGMM[n_gaussians].at<cv::Vec3b>(i, j)[c] = _weightsGMM[n_gaussians].at<cv::Vec3b>(i, j)[c] * w_ratio_old2new_gaussian;// New weight as 69% of te substituded

					}else{

						//There is room for more gaussians! Lets create a new one in the index of the number of gaussians
						_meanGMM[n_gaussians].at<cv::Vec3b>(i, j)[c] = Frame.at<cv::Vec3b>(i, j)[c];
						_sigmaGMM[n_gaussians].at<cv::Vec3b>(i, j)[c] = _initial_sigma;
						_weightsGMM[n_gaussians].at<cv::Vec3b>(i, j)[c] = 0.1;
						_Ngaussians.at<cv::Vec3b>(i, j)[c] = _Ngaussians.at<cv::Vec3b>(i, j)[c] +1;

					}
					//No matter if we have created a new gaussian or it has been added we have to update the weights
					this->normalize_weights(i,j,c);
				}
			}//End loop -> image channels
		}//End loop -> image cols
	}//End loop -> image rows
}

void gaussianMM::update_GMM_mask(cv::Mat Frame,double threshold)
{
	for (int i = 0; i < Frame.rows; ++i) {
		for (int j = 0; j < Frame.cols; ++j) {//Iteration over each pixel of the Frame
			double pixel_confidence = 0.0;
			for(int c = 0; c < 3; ++c){
				int pixel_value = Frame.at<cv::Vec3b>(i, j)[c];
				for(int g = 0; g < _Ngaussians.at<cv::Vec3b>(i, j)[c] ; ++g){
					if(is_pixel_in_gaussian( pixel_value,  i,  j,  c, g)){
						pixel_confidence += _weightsGMM[g].at<cv::Vec3b>(i, j)[c];
					}

				}
			}
			if(pixel_confidence > pixel_confidence){
				_ForegroundGMM.at<uchar>(i, j)=255;
			}

		}//End iteraton forevery pixel
	}
}


bgs::bgs(double threshold, double alpha, int threshold_ghosts2, bool rgb) {
	_rgb = rgb;

	_threshold = threshold;

	//New parameters for the constructor
	_alpha = alpha;

	_threshold_ghosts2 = threshold_ghosts2;

}

//default destructor
bgs::~bgs(void) {
}

//method to initialize bkg (first frame - hot start)
void bgs::init_bkg(cv::Mat Frame) {

	if (!_rgb) {
		cvtColor(Frame, Frame, COLOR_BGR2GRAY); // to work with gray even if input is color
		counter = cv::Mat::zeros(Size(Frame.cols, Frame.rows), CV_8UC1);
		_bkg = Mat::zeros(Size(Frame.cols, Frame.rows), CV_8UC1); // void function for Lab1.0 - returns zero matrix
		//ADD YOUR CODE HERE
		//...
		Frame.copyTo(_bkg);
		//...
	} else {
		// Initialize _bkg for rgb input
		//CV_<bit-depth>{U|S|F}C(<number_of_channels>)
		_bkg = Mat::zeros(Size(Frame.cols, Frame.rows), CV_8UC3);

		// Initialize counter for suppression of ghosts
		counter = cv::Mat::zeros(Size(Frame.cols, Frame.rows), CV_8UC3);
		Frame.copyTo(_bkg);

	}

}

//method to perform BackGroundSubtraction
void bgs::bkgSubtraction(cv::Mat Frame) {

	if (!_rgb) {
		cvtColor(Frame, Frame, COLOR_BGR2GRAY); // to work with gray even if input is color

		Frame.copyTo(_frame);

		_diff = Mat::zeros(Size(Frame.cols, Frame.rows), CV_8UC1); // void function for Lab1.0 - returns zero matrix
		//_bgsmask = Mat::zeros(Size(Frame.cols, Frame.rows), CV_8UC1); // void function for Lab1.0 - returns zero matrix
		//ADD YOUR CODE HERE
		//...

		// Calculating _bkg from the equation
		_bkg = (_alpha * _frame) + (1 - _alpha) * _bkg;

		// Calculating absolute difference between image and background pixels
		absdiff(_bkg, _frame, _diff);

		// If the previously calculated difference is bigger than the threshold the pixel belongs to foreground
		// Threshold for the binary mask
		threshold(_diff, _bgsmask, _threshold, 255, THRESH_BINARY);

		//Loop through every pixel
		for (int i = 0; i < _frame.rows; ++i) {
			for (int j = 0; j < _frame.cols; ++j) {

				// Counter increases every time the pixel is detected as foreground
				if (_bgsmask.at<uchar>(i, j) == 255) {
					counter.at<uchar>(i, j) = counter.at<uchar>(i, j) + 1;

					// Pixel becomes background if the counter reaches the threshold
					if (double(counter.at<uchar>(i, j)) >= _threshold_ghosts2) {
						_bkg.at<uchar>(i, j) = _frame.at<uchar>(i, j);
					}
				}
				// Counter resets every time the pixel is detected as background
				else if (_bgsmask.at<uchar>(i, j) == 0) {
					counter.at<uchar>(i, j) = 0;
				}
			}
		}

		//...
	} else {


		Frame.copyTo(_frame);

		_diff = Mat::zeros(Size(Frame.cols,Frame.rows), CV_8UC1);
		//_bgsmask = Mat::zeros(Size(Frame.cols,Frame.rows), CV_8UC3);

		// Calculating _bkg from the equation
		_bkg = (_alpha * _frame) + (1 - _alpha) * _bkg;

		// Calculating absolute difference between image and background pixels
		absdiff(_bkg, _frame, _diff);


		// If the previously calculated difference is bigger than the threshold the pixel belongs to foreground
		// Threshold for the binary mask

		threshold(_diff, _bgsmask, _threshold, 255, THRESH_BINARY);

		//Loop through every pixel
		for (int i = 0; i < _frame.rows; ++i) {
			for (int j = 0; j < _frame.cols; ++j) {

				// Loop through the 3 color channel
				for (int k = 0; k < 3; k++) {

					// Counter increases every time the pixel is detected as foreground
					if (_bgsmask.at<cv::Vec3b>(i, j)[k] == 255) {
						counter.at<cv::Vec3b>(i, j)[k] = double(
								counter.at<cv::Vec3b>(i, j)[k]) + 1;

						// Pixel becomes background if the counter reaches the threshold
						if (double(counter.at<cv::Vec3b>(i, j)[k])
								>= _threshold_ghosts2) {
							_bkg.at<cv::Vec3b>(i, j)[k] = _frame.at<cv::Vec3b>(
									i, j)[k];
						}
					}
					// Counter resets every time the pixel is detected as background
					else if (_bgsmask.at<cv::Vec3b>(i, j)[k] == 0) {
						counter.at<cv::Vec3b>(i, j)[k] = 0;
					}
				}
			}
		}
	}
}

//method to detect and remove shadows in the BGS mask to create FG mask
void bgs::removeShadows() {
	// init Shadow Mask (currently Shadow Detection not implemented)
	//_bgsmask.copyTo(_shadowmask); // creates the mask (currently with bgs)

	//ADD YOUR CODE HERE
	//...

	cvtColor(_bgsmask,_bgsmask,CV_RGB2GRAY);
	//...
	//_shadowmask.copyTo(_fgmask);
	absdiff(_bgsmask, _shadowmask, _fgmask); // eliminates shadows from bgsmask
}
void bgs::update_shadowmask(cv::Mat Frame, double alpha_shdw, double beta_shdw,
		double tau_shdw_s, double tau_shdw_h) {

	// Initialize and convert to hsv
	cv::Mat hsv_frame = cv::Mat::zeros(Size(Frame.cols, Frame.rows), CV_8UC3);
	cvtColor(Frame, hsv_frame, CV_BGR2HSV); // converting rgb to hsv

	cv::Mat hsv_bkg = cv::Mat::zeros(Size(Frame.cols, Frame.rows), CV_8UC3);
	cvtColor(_bkg, hsv_bkg, CV_BGR2HSV); // converting rgb to hsv

	_shadowmask = Mat::zeros(Size(Frame.cols, Frame.rows), CV_8UC1);

	// help funtion for noise filtering
	cv::Mat help = Mat::zeros(Size(Frame.cols, Frame.rows), CV_8UC1);
	_bgsmask.copyTo(help);
	if (_bgsmask.type() == 16) {
		cvtColor(_bgsmask, help, CV_RGB2GRAY);

	}

//	//Loop through every pixel
	for (int i = 0; i < hsv_frame.rows; ++i) {
		for (int j = 0; j < hsv_frame.cols; ++j) {
			// Create the frame HSV values
			double pixel_frame_H = double(hsv_frame.at<cv::Vec3b>(i, j)[0]) * 2;
			double pixel_frame_S = double(hsv_frame.at<cv::Vec3b>(i, j)[1]);
			double pixel_frame_V = double(hsv_frame.at<cv::Vec3b>(i, j)[2]);
			if (pixel_frame_V == 0) {
				pixel_frame_V = 1.0;
			}

			// Create the BKG HSV values
			double pixel_bkg_H = double(hsv_bkg.at<cv::Vec3b>(i, j)[0]) * 2;
			double pixel_bkg_S = double(hsv_bkg.at<cv::Vec3b>(i, j)[1]);
			double pixel_bkg_V = double(hsv_bkg.at<cv::Vec3b>(i, j)[2]);

			// Calculate the needed equations
			double compare_alpha_beta = pixel_frame_V / pixel_bkg_V;
			double compare_beta = std::abs(pixel_frame_S - pixel_bkg_S);
			double Dh = std::min(double(std::abs(pixel_frame_H - pixel_bkg_H)),
					double(360 - std::abs(pixel_frame_H - pixel_bkg_H)));

			// Condition for shadowmask
			if ((alpha_shdw <= compare_alpha_beta)
					&& (compare_alpha_beta <= beta_shdw)
					&& (compare_beta <= tau_shdw_s) && (Dh <= tau_shdw_h)) {
				_shadowmask.at<uchar>(i, j) = 255;

				// Noise filtering
				if (help.at<uchar>(i, j) == 0) {
					_shadowmask.at<uchar>(i, j) = 0;
				}

			}
		}
	}

//	// Define the kernel for morphological opening
//	Mat kernel = getStructuringElement(MORPH_OPEN, Size(6, 6));
//
//  // Perform morphological opening
//
//	morphologyEx(_shadowmask, _shadowmask, MORPH_OPEN, kernel);
//	morphologyEx(_shadowmask, _shadowmask, MORPH_CLOSE, kernel);

}


